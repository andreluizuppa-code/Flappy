# Flappy Bot (protótipo Android)

Projeto-fonte inicial em Kotlin para Android 11+ (inclui Android 13). Não é um APK pronto.

## O que já existe
- Tela simples com iniciar/parar.
- Serviço de acessibilidade que tenta capturar a tela com `takeScreenshot`.
- Heurística experimental para localizar faixas verdes dos cactos e emitir toques.
- As imagens são processadas localmente; não há envio de tela para servidor.

## Limitações importantes
Este é um **protótipo não validado no TikTok**. A detecção do personagem usa uma aproximação pela borda clara do avatar, e o detector dos cactos pode confundir elementos do cenário. A lógica precisa ser calibrada com gravações reais antes de ser considerada utilizável. Não há garantia de pontuação ou de sobrevivência.

## Como compilar
Abra a pasta no Android Studio em um computador com Android SDK instalado e compile o módulo `app`. O projeto não inclui APK pré-compilado nem Gradle Wrapper.

## Permissão
Depois de instalar, abra Configurações > Acessibilidade e ative “Flappy Bot - controle”. Volte ao app, toque em INICIAR BOT e abra o minigame. Desative o serviço quando terminar.
