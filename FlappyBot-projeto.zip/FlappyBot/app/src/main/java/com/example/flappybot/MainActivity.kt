package com.example.flappybot

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("bot", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 40, 32, 40)
            setBackgroundColor(0xFFF4F0E8.toInt())
        }
        val title = TextView(this).apply {
            text = "FLAPPY BOT"
            textSize = 30f
            setTextColor(0xFF183B2A.toInt())
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "Protótipo experimental para o minigame do TikTok.\n\n1) Ative o serviço de acessibilidade.\n2) Volte aqui e ligue o bot.\n3) Abra o minigame.\n\nO detector ainda precisa ser calibrado no jogo real."
            textSize = 16f
            setTextColor(0xFF333333.toInt())
            setPadding(0, 28, 0, 28)
        }
        val access = Button(this).apply {
            text = "CONFIGURAR ACESSIBILIDADE"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val toggle = Button(this).apply {
            text = if (prefs.getBoolean("enabled", false)) "PARAR BOT" else "INICIAR BOT"
            setOnClickListener {
                val next = !prefs.getBoolean("enabled", false)
                prefs.edit().putBoolean("enabled", next).apply()
                text = if (next) "PARAR BOT" else "INICIAR BOT"
            }
        }
        val disclaimer = TextView(this).apply {
            text = "Use somente enquanto estiver vendo o jogo. O app não coleta nem envia imagens."
            textSize = 12f
            setTextColor(0xFF666666.toInt())
            setPadding(0, 24, 0, 0)
        }
        root.addView(title); root.addView(info); root.addView(access); root.addView(toggle); root.addView(disclaimer)
        setContentView(root)
    }
}
