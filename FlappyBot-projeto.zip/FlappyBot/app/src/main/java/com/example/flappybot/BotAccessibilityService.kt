package com.example.flappybot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.graphics.Bitmap
import android.graphics.Color
import android.hardware.HardwareBuffer
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import java.util.concurrent.Executor
import kotlin.math.abs

/** Experimental visual controller. It is intentionally conservative and may miss obstacles. */
class BotAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var busy = false
    private var lastTapAt = 0L
    private val loop = object : Runnable {
        override fun run() {
            val enabled = getSharedPreferences("bot", MODE_PRIVATE).getBoolean("enabled", false)
            if (enabled && !busy) captureAndAnalyze()
            handler.postDelayed(this, 180L)
        }
    }

    override fun onServiceConnected() { handler.post(loop) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { getSharedPreferences("bot", MODE_PRIVATE).edit().putBoolean("enabled", false).apply() }
    override fun onDestroy() { handler.removeCallbacks(loop); super.onDestroy() }

    private fun captureAndAnalyze() {
        if (android.os.Build.VERSION.SDK_INT < 30) return
        busy = true
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, Executor { it.run() }, object : TakeScreenshotCallback {
                override fun onSuccess(result: ScreenshotResult) {
                    var bitmap: Bitmap? = null
                    try {
                        val buffer: HardwareBuffer = result.hardwareBuffer
                        bitmap = Bitmap.wrapHardwareBuffer(buffer, result.colorSpace)
                        buffer.close()
                        if (bitmap != null) decide(bitmap)
                    } catch (_: Exception) {
                    } finally {
                        bitmap?.recycle()
                        busy = false
                    }
                }
                override fun onFailure(errorCode: Int) { busy = false }
            })
        } catch (_: Exception) { busy = false }
    }

    private data class Gap(val x: Int, val top: Int, val bottom: Int) { val center get() = (top + bottom) / 2 }

    private fun decide(b: Bitmap) {
        val w = b.width; val h = b.height
        if (w < 100 || h < 200) return
        // Cacti are green. Scan columns ahead of the avatar and find columns with two green bands.
        val candidates = mutableListOf<Gap>()
        val xStart = (w * 0.36f).toInt()
        val xEnd = (w * 0.88f).toInt()
        val step = (w * 0.012f).toInt().coerceAtLeast(3)
        for (x in xStart..xEnd step step) {
            val bands = mutableListOf<Pair<Int, Int>>()
            var start = -1
            for (y in 0 until h) {
                val c = b.getPixel(x, y)
                val r = Color.red(c); val g = Color.green(c); val bl = Color.blue(c)
                val green = g > 65 && g > r * 1.12 && g > bl * 0.88 && (g - r) > 8
                if (green && start < 0) start = y
                if ((!green || y == h - 1) && start >= 0) {
                    val end = y - 1
                    if (end - start > h * 0.055f) bands.add(start to end)
                    start = -1
                }
            }
            if (bands.size >= 2) {
                // Choose the largest clear interval between consecutive cactus bands.
                for (i in 0 until bands.size - 1) {
                    val topEnd = bands[i].second
                    val bottomStart = bands[i + 1].first
                    val gapSize = bottomStart - topEnd
                    if (gapSize in (h * 0.10f).toInt()..(h * 0.48f).toInt()) {
                        candidates.add(Gap(x, topEnd, bottomStart))
                    }
                }
            }
        }
        if (candidates.isEmpty()) return
        val playerX = (w * 0.25f).toInt()
        val target = candidates.minByOrNull { abs(it.x - w * 0.58f) } ?: return
        // Approximate avatar center from the bright circular rim in its usual left-side region.
        val y0 = (h * 0.25f).toInt(); val y1 = (h * 0.78f).toInt()
        var sumY = 0L; var count = 0
        for (y in y0..y1 step 2) for (x in (w * 0.12f).toInt()..(w * 0.36f).toInt() step 2) {
            val c = b.getPixel(x, y)
            val r = Color.red(c); val g = Color.green(c); val bl = Color.blue(c)
            if (r > 205 && g > 205 && bl > 205 && abs(x - playerX) < w * 0.12f) { sumY += y; count++ }
        }
        if (count < 8) return
        val playerY = (sumY / count).toInt()
        val targetY = target.center
        val now = System.currentTimeMillis()
        // A tap gives upward lift. Keep a cooldown to avoid holding the screen down.
        if (playerY > targetY + h * 0.055f && now - lastTapAt > 360L) {
            tap(w * 0.25f, h * 0.52f)
            lastTapAt = now
        }
    }

    private fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 55))
            .build()
        dispatchGesture(gesture, null, null)
    }
}
